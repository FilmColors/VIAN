.. _screenshots:

Screenshots
===========
Screenshots are Awesome

.. toctree::
   :maxdepth: 2

   create_screenshot
   export_screenshots


* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


