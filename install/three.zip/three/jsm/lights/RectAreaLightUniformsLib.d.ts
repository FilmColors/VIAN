export namespace RectAreaLightUniformsLib {

	export function init(): void;

}
