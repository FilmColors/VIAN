from core.analysis.barcode.barcode_analysis import BarcodeAnalysisJob
from core.analysis.movie_mosaic.movie_mosaic import MovieMosaicAnalysis
from core.analysis.colorimetry.colormetry2 import ColormetryJob2