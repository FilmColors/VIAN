.. _Nodes:

Nodes
=====
The Timeline is used for all modifications of the VIAN project that is directed to time-dependent entities and as such
the a major component of the UI.
Use the Timeline to create and modify *Segmentations*, *Segments*, *Screenshots* and *Annotation Layers*.




* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`