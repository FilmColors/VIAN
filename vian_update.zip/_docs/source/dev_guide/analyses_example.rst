.. _IAnalysisJobExample:

IAnalysisJob Example
====================

.. literalinclude:: E:\\\\Programming\\Git\\visual-movie-annotator\\extensions\\analysis\\barcode\\barcode_analysis.py
   :language: python
   :linenos:



* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`cd _docs