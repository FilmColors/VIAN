.. filmpalette documentation master file, created by
   sphinx-quickstart on Sun Jul 30 23:04:30 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

==========
What's New
==========

In this section, all release notes are collected since 0.4.1.

.. toctree::
    :maxdepth: 4

    whats_new/latest
    whats_new/0_4_2/0_4_2.rst


