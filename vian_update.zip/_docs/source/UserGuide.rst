.. filmpalette documentation master file, created by
   sphinx-quickstart on Sun Jul 30 23:04:30 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

============
User's Guide
============
Welcome to the User's Guide of VIAN. In this documentation you'll find all information necessary to get the most out
of VIAN. If your a developer, please refer to the Developer's Guide.

.. toctree::
    :maxdepth: 4

    user_interface/user_interface
    step_by_step/step_by_step


