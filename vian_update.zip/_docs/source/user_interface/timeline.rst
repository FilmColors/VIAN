Timeline
========
The Timeline is used for all modifications of the VIAN project that is directed to time-dependent entities and as such
the a major component of the UI.
Use the Timeline to create and modify *Segmentations*, *Segments*, *Screenshots* and *Annotation Layers*.


.. figure:: timeline_01.png
   :scale: 100 %
   :align: center
   :alt: map to buried treasure

   The Timeline of VIAN.

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`