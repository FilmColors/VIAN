.. VIAM documentation master file, created by
   sphinx-quickstart on Sun Nov 19 19:47:14 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to VIAN's documentation!
================================


.. toctree::
   :maxdepth: 4

   UserGuide
   DevelopersGuide



* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
