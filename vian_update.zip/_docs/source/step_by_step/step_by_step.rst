Step-by-Step Guides
===================


.. toctree::
   :maxdepth: 2

   project_management/project_management
   segmentation/segmentation.rst
   annotation/annotation.rst
   screenshots/screenshots.rst





* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`