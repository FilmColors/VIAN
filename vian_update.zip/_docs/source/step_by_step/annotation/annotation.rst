.. _annotation:

Annotations
===========
Annotations are awesome!
... But not yet documented :-(

.. toctree::
   :maxdepth: 4


