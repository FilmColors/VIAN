.. _change_subtitles:

Changing Subtitles
******************


Change the Subtitles as follows:

1. In the **Player Controls** Window press on the **Show Slider** Button (If you cant see this window use **ALT + P** to show it)
2. Choose the Subtitle on the right side of the Window

.. figure:: sub_01.jpg
   :scale: 80 %
   :align: center
   :alt: map to buried treasure

.. figure:: sub_02.jpg
   :scale: 80 %
   :align: center
   :alt: map to buried treasure

.. seealso::

   * :ref:`player`


* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`