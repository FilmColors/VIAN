.. _player:

VIAN's Player
=============

VIAN uses libVLC in the backend, enabling us to use merely all libVLC specific functionality,
and serving with a adequate stability.
In the following pages, there are some explanations on how to use VIAN's Player Window and
how to control specific properties.


.. toctree::
   :maxdepth: 2

   changing_subtitles


* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


