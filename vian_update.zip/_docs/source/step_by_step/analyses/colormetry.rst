.. _colormetry:

**********
Colormetry
**********

The Colormetry Analysis is an integral Part of VIAN and is used to compute some
of the most important color-features for the later analysis.

There are two possible ways to handle the Colormetry, either set it to start automatically
when a new project is created in **Preferences/Behaviour/Auto-Start-Colormetry** or Run it
by navigating to **Analysis/Colormetry**.

As soon as the Colormetry is running a green bar will appear in the Timeline.



.. seealso::

   * :ref:`analyses`
   * :ref:`viewing_analyses`
   * :ref:`viewing_analyses`

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`




