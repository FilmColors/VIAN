print ("method".__class__)
print (u"method".__class__)